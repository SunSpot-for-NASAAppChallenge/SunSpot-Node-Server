//
//  ViewController.m
//  SunSpot
//
//  Created by Todd Bernhard on 4/30/17.
//  Copyright © 2017 No Tie. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import <AVFoundation/AVFoundation.h>

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0)

@interface ViewController ()


@end

NSString * serverURL;
NSString * zipcode;
NSString * fontstring;
NSString * title;
NSString * mainText;
NSString * tospeak;

NSInteger screenwidth,screenheight,fontsize,xmargin,ymargin, buttonsize;

id fontcolor;

CLLocationManager * locationManager;
UITextField * zipField;
UILabel * info;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self initializeVariables];
    [self showMenu];
//    [self getLocation];
    [self askLocation];
    [self update];
}


-(void)initializeVariables {

    serverURL = @"https://stark-mountain-84054.herokuapp.com/?action=retrieve";
//    serverURL = @"https://notiesoftware.com/SunSpot/sunspot.php";
//    zipcode = @"14623";
    zipcode = @"";

    fontstring = @"Futura-Medium";
    fontcolor = [UIColor whiteColor];
    
    [NSUserDefaults resetStandardUserDefaults];
    
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    CGSize screenSize = screenBound.size;
    screenwidth = screenSize.width;
    screenheight = screenSize.height;
    
    fontsize=24; // was 18
    xmargin = 4;
    ymargin = 4;
    
    buttonsize = fontsize * 3;

}

-(void)showMenu {
    
        UIImageView * logo = [[UIImageView alloc] init];
//    logo.frame = CGRectMake(xmargin + buttonsize, ymargin, screenwidth-2*xmargin - 2*buttonsize, buttonsize);
    logo.frame = CGRectMake(xmargin, ymargin, buttonsize, buttonsize);
        logo.image = [UIImage imageNamed:@"SunSpotSquare512.png"];
        logo.contentMode = UIViewContentModeScaleAspectFit;
        [self.view addSubview:logo];
    
    UILabel * headline = [[UILabel alloc] init];
    
    headline.frame = CGRectMake(buttonsize+xmargin, 0,  screenwidth - 2*(xmargin+buttonsize), buttonsize);
    headline.text = @"Welcome to Sun Spot!";
    headline.textAlignment = NSTextAlignmentCenter;
    headline.backgroundColor = [UIColor clearColor];
    headline.textColor = [UIColor blackColor];
    headline.adjustsFontSizeToFitWidth=YES;
    headline.minimumScaleFactor=0.5;
    headline.font = [UIFont fontWithName:fontstring size:fontsize];
    [self.view addSubview:headline];
    
        /*
        UIButton * settings = [[UIButton alloc] init];
        //    settings.frame = CGRectMake(screenwidth - buttonsize, 0, buttonsize, buttonsize);
        settings.frame = CGRectMake(0, 0, buttonsize, buttonsize);
        [settings setImage:[UIImage imageNamed:@"CCSettingsGear.png"] forState:UIControlStateNormal];
        settings.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [settings addTarget:self action:@selector(settingsPressed) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:settings];
        */
    
        
        info = [[UILabel alloc] init];
        
        info.frame = CGRectMake(xmargin, 2* (buttonsize+ymargin),  screenwidth - 2*xmargin, screenheight-2*(buttonsize+ymargin));
        info.text = @"Sun Spot is the home of your customized beach, sun, wind and water report, courtesy of NASA and other trusted sources!";
        info.textAlignment = NSTextAlignmentCenter;
        info.backgroundColor = [UIColor clearColor];
        info.textColor = [UIColor blackColor];
        info.adjustsFontSizeToFitWidth=YES;
        info.minimumScaleFactor=0.5;
        info.numberOfLines =0;
        info.font = [UIFont fontWithName:fontstring size:fontsize];
        [self.view addSubview:info];
}

-(void) speak {
    
    NSString *voicestring = @"en-US"; // US Female
    
    /*
    if ([[CommonUserDetails sharedUserDetails].voice  isEqualToString:@"Female"])  {voicestring = @"en-US";} // Female
    if ([[CommonUserDetails sharedUserDetails].voice isEqualToString:@"S.Africa"]) {voicestring = @"en-ZA";} // Female
    if ([[CommonUserDetails sharedUserDetails].voice isEqualToString:@"Oz"]) {voicestring = @"en-AU";} // Female
    if ([[CommonUserDetails sharedUserDetails].voice isEqualToString:@"UK"]) {voicestring = @"en-GB";} // Male
    if ([[CommonUserDetails sharedUserDetails].voice isEqualToString:@"Male"]) {voicestring = @"en-GB";} // Male
    if ([[CommonUserDetails sharedUserDetails].voice isEqualToString:@"Irish"]) {voicestring = @"en-IE";} // Female
    */
    
    
    // if AmericanMan then use TTS voices as not available in iOS 7
    
    /*
     "[AVSpeechSynthesisVoice 0x978a0b0] Language: th-TH",
     "[AVSpeechSynthesisVoice 0x977a450] Language: pt-BR",
     "[AVSpeechSynthesisVoice 0x977a480] Language: sk-SK",
     "[AVSpeechSynthesisVoice 0x978ad50] Language: fr-CA",
     "[AVSpeechSynthesisVoice 0x978ada0] Language: ro-RO",
     "[AVSpeechSynthesisVoice 0x97823f0] Language: no-NO",
     "[AVSpeechSynthesisVoice 0x978e7b0] Language: fi-FI",
     "[AVSpeechSynthesisVoice 0x978af50] Language: pl-PL",
     "[AVSpeechSynthesisVoice 0x978afa0] Language: de-DE",
     "[AVSpeechSynthesisVoice 0x978e390] Language: nl-NL",
     "[AVSpeechSynthesisVoice 0x978b030] Language: id-ID",
     "[AVSpeechSynthesisVoice 0x978b080] Language: tr-TR",
     "[AVSpeechSynthesisVoice 0x978b0d0] Language: it-IT",
     "[AVSpeechSynthesisVoice 0x978b120] Language: pt-PT",
     "[AVSpeechSynthesisVoice 0x978b170] Language: fr-FR",
     "[AVSpeechSynthesisVoice 0x978b1c0] Language: ru-RU",
     "[AVSpeechSynthesisVoice 0x978b210] Language: es-MX",
     "[AVSpeechSynthesisVoice 0x978b2d0] Language: zh-HK",
     "[AVSpeechSynthesisVoice 0x978b320] Language: sv-SE",
     "[AVSpeechSynthesisVoice 0x978b010] Language: hu-HU",
     "[AVSpeechSynthesisVoice 0x978b440] Language: zh-TW",
     "[AVSpeechSynthesisVoice 0x978b490] Language: es-ES",
     "[AVSpeechSynthesisVoice 0x978b4e0] Language: zh-CN",
     "[AVSpeechSynthesisVoice 0x978b530] Language: nl-BE",
     "[AVSpeechSynthesisVoice 0x978b580] Language: en-GB",
     "[AVSpeechSynthesisVoice 0x978b5d0] Language: ar-SA",
     "[AVSpeechSynthesisVoice 0x978b620] Language: ko-KR",
     "[AVSpeechSynthesisVoice 0x978b670] Language: cs-CZ",
     "[AVSpeechSynthesisVoice 0x978af20] Language: da-DK",
     "[AVSpeechSynthesisVoice 0x978b8b0] Language: hi-IN",
     "[AVSpeechSynthesisVoice 0x978b900] Language: el-GR",
     "[AVSpeechSynthesisVoice 0x978b950] Language: ja-JP"
     */
    
    // consider stopping synth if still speaking earlier phrases
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:tospeak];
    AVSpeechSynthesizer * synth = [[AVSpeechSynthesizer alloc] init];
    //        utterance.rate = 1.0;
    utterance.rate = 0.5;
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:voicestring];
    utterance.volume = 1.0;
    utterance.pitchMultiplier = 1;
    [synth speakUtterance:utterance];

}

-(void) update {
    [zipField resignFirstResponder];

    zipcode = zipField.text;
    
    if ([zipcode isEqualToString:@""]) {zipcode = @"14623";}
    /*
    NSLog(@"zip:%@",zipcode);
    
    switch (zipcode.integerValue) {
        case 90210 : mainText = @"The Air Quality Index is poor today, so stay indoors. Try a Virtual Reality game instead!"; break;
        case 2134 : mainText = @"The Sharknado appears to be over, so enjoy surfing. Waves are a toasty ten feet so have a gnarly day!"; break;
        case 86756 : mainText = @"Today is a good day to launch a rocket ship! Have a great launch!"; break;
        default : mainText = @"Charlotte Beach is closed due to poor lake conditions. If you do visit, have an ice cream cone from Abbotts and tell them Sun Spot sent you!";break;
    }
    
    title = [NSString stringWithFormat:@"Sun Spot Report"];
    info.text = mainText;
tospeak = [NSString stringWithFormat:@"%@ . %@",title,mainText];
[self speak];

     */
    

    NSString * urlString = [NSString stringWithFormat:@"%@&zipcode=%@",serverURL,zipcode];
    
    NSLog(@"Accessing: %@",urlString);
    // get data from server
    NSURL * url = [NSURL URLWithString:urlString];
    
//    NSLog(@"%@",[NSString stringWithContentsOfURL:url]);


    // parse JSON
    dispatch_async(kBgQueue,^{
        NSData* data = [NSData dataWithContentsOfURL:url];
        [self performSelectorOnMainThread:@selector(gotData:)
                               withObject:data waitUntilDone:YES];
    });
    
    // speak and show text response
    
}

-(void)gotData:(NSData *)jData {
    NSLog(@"in got data");
        
    if (!((jData == nil) || ([jData isKindOfClass:[NSNull class]]))) {
        
        NSError* error;
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:jData options:kNilOptions error:&error];
        if (!error) {
            NSLog(@"%@",json);
            
                title = [json objectForKey:@"titleText"];
                mainText = [json objectForKey:@"mainText"];
        }
            

        NSLog(@"TITLE: %@",title);
        NSLog(@"MAIN: %@",mainText);
    }
    else {
        title = @"Welcome to the Sun Spot Report.";
        mainText = info.text;
    }

    info.text = mainText;
    tospeak = [NSString stringWithFormat:@"%@ . %@",title,mainText];
    [self speak];
}



-(void)askLocation {
    
    zipField = [[UITextField alloc] init];
    zipField.frame = CGRectMake(xmargin, 100, screenwidth - 2*xmargin, fontsize *2);
    zipField.keyboardType = UIKeyboardTypeNumberPad;
    [zipField setDelegate:(id)self];
    zipField.borderStyle = UITextBorderStyleRoundedRect;
    zipField.font = [UIFont fontWithName:@"Futura" size:32];
    zipField.text = zipcode;
    zipField.placeholder = @"enter zipcode";
    zipField.autocorrectionType = UITextAutocorrectionTypeNo;
    zipField.returnKeyType = UIReturnKeyDone;
    zipField.textAlignment = NSTextAlignmentCenter;
    zipField.clearButtonMode = UITextFieldViewModeWhileEditing;
    zipField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

    [self.view addSubview:zipField];
    
    UIButton * goButton = [[UIButton alloc] init];
    goButton.frame = CGRectMake(xmargin, 100+ ymargin + fontsize *2, screenwidth-2*xmargin, fontsize*2);
    [goButton setBackgroundImage:[[UIImage imageNamed:@"greenbutton.png"] stretchableImageWithLeftCapWidth:10.0 topCapHeight:0.0] forState:UIControlStateNormal];
    [goButton setTitle:@"Get my Sun Spot report!" forState:UIControlStateNormal];
    [goButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    goButton.tag = 0;
    [goButton addTarget:self action:@selector(update) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:goButton];

}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];

    return YES;
}


-(void) doneEditing: (id) sender {
    [self update];
}

/*

-(void) getLocation {
    
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = (id)self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.distanceFilter = kCLDistanceFilterNone;
        [locationManager startUpdatingLocation];
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        
        //In ViewDidLoad
        if(IS_OS_8_OR_LATER) {
            //            [self.locationManager requestAlwaysAuthorization];
            [locationManager requestWhenInUseAuthorization];
        }    CLLocation *location = [locationManager location];
        
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        CLLocationManager * lm = [[CLLocationManager alloc]init];
        lm.delegate = (id)self;
        [lm startUpdatingLocation];
        
        float longitude=location.coordinate.longitude;
        float latitude=location.coordinate.latitude;
        NSString *latitudestring = [NSString stringWithFormat: @"%f", latitude];
        NSString *longitudestring = [NSString stringWithFormat: @"%f", longitude];
    
                NSLog(@"GPS = %@, %@",latitudestring,longitudestring);
        //Block address
        [geocoder reverseGeocodeLocation: lm.location completionHandler:
         ^(NSArray *placemarks, NSError *error) {
             
             //Get address
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             
             zipcode = [placemark.addressDictionary valueForKey:@"PostalCode"];
             
             NSLog(@"Zipcode = %@",zipcode);
             
                NSString * locatedaddress = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];

             NSLog(@"ADDRESS: %@",locatedaddress);
             
             /*
             [CommonUserDetails sharedUserDetails].address = [NSString stringWithFormat:@"%@", locatedaddress];
             [CommonUserDetails sharedUserDetails].latitude = [NSString stringWithFormat:@"%@", latitudestring];
             [CommonUserDetails sharedUserDetails].longitude = [NSString stringWithFormat:@"%@", longitudestring];         [CommonUserDetails sharedUserDetails].postalcode = [NSString stringWithFormat:@"%@", [placemark.addressDictionary valueForKey:@"PostalCode"]];
             [CommonUserDetails sharedUserDetails].country = [NSString stringWithFormat:@"%@", [placemark.addressDictionary valueForKey:@"Country"]];
             [CommonUserDetails sharedUserDetails].state = [NSString stringWithFormat:@"%@", [placemark.addressDictionary valueForKey:@"State"]];
             [CommonUserDetails sharedUserDetails].city = [NSString stringWithFormat:@"%@", [placemark.addressDictionary valueForKey:@"City"]];
             [[CommonUserDetails sharedUserDetails] saveToUserDefaults];
             [self updateInstructions];
 
         }];

}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"didUpdateToLocation: %@", newLocation);
 //   CLLocation *currentLocation = newLocation;
    
}
*/




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
